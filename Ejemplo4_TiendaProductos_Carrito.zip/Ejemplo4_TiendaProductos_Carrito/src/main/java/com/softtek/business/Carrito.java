package com.softtek.business;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.softtek.models.Producto;

public class Carrito implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6811171507778582309L;
	
	private List<Producto> contenido = new ArrayList<Producto>();
	private double importe;
	
	public void addProducto(int id) {
		NegocioTienda negocio = new NegocioTienda();
		Producto producto = negocio.buscar(id);
		contenido.add(producto);
		importe += producto.getPrecio();
		importe = Math.round(importe *100)/100;
	}
	
	public void sacarProducto(int id) {
		
		Producto encontrado = null;
		
		for (Producto p : contenido) {
			if (id == p.getId()) {
				encontrado = p;
				break;
			}
		}
		
		if (encontrado != null) {
			contenido.remove(encontrado);
			importe -= encontrado.getPrecio();
		}
		
		importe = Math.round(importe *100)/100;
	}
	
	public List<Producto> getContenido() {
		return contenido;
	}
	
	public double getImporte() {
		return importe;
	}

	

}
