package com.softtek.business;

import java.util.List;

import com.softtek.models.Producto;
import com.softtek.persistence.ProductosDAO;

public class NegocioTienda {
	
	private ProductosDAO dao = new ProductosDAO();
	
	public List<Producto> todos(){
		return dao.consultarTodos();
	}

}
