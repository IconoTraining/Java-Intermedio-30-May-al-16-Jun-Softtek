package com.softtek.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;


import com.softtek.models.Producto;

// DAO -> Data Access Object
public class ProductosDAO {
	
	private Connection conexion;
	
	public boolean modificarProducto(int id, double nuevoPrecio){
		boolean modificado = false;
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "update PRODUCTOS set PRECIO=? where ID=?";
			PreparedStatement stm = conexion.prepareStatement(sql);
			
			// 2.- Resolver los parametros "Empieza a contar desde 1"
			stm.setDouble(1, nuevoPrecio);
			stm.setInt(2, id);		
			
			// 3.- Lanzar la query y recoger el resultado
			int registros = stm.executeUpdate();
			
			// 4.- Procesar el resultado
			if(registros == 1) {
				modificado = true;
			}
			
		} catch (Exception e) {
			System.out.println("Error al modificar el alumno con id " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		return modificado;
		
	}
	
	public boolean borrarProducto(int id){
		boolean eliminado = false;
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "delete from PRODUCTOS where ID=?";
			PreparedStatement stm = conexion.prepareStatement(sql);
			
			// 2.- Resolver los parametros "Empieza a contar desde 1"
			stm.setInt(1, id);		
			
			// 3.- Lanzar la query y recoger el resultado
			int registros = stm.executeUpdate();
			
			// 4.- Procesar el resultado
			if(registros == 1) {
				eliminado = true;
			}
			
		} catch (Exception e) {
			System.out.println("Error al eliminar el producto con id " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		return eliminado;
		
	}
	
	public boolean insertarProducto(Producto nuevo){
		
		boolean insertado = false;
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "insert into PRODUCTOS values (?,?,?)";
			PreparedStatement stm = conexion.prepareStatement(sql);
			
			// 2.- Resolver los parametros "Empieza a contar desde 1"
			stm.setInt(1, nuevo.getId());
			stm.setString(2, nuevo.getDescripcion());
			stm.setDouble(3, nuevo.getPrecio());
			
			// 3.- Lanzar la query y recoger el resultado
			int registros = stm.executeUpdate();
			
			// 4.- Procesar el resultado
			if(registros == 1) {
				insertado = true;
			}
			
		} catch (Exception e) {
			System.out.println("Error al insertar el producto " + nuevo);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		return insertado;
		
	}
	
	public Producto buscarProducto(int id){
		
		Producto encontrado = new Producto();
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "select * from PRODUCTOS where ID = ?";
			PreparedStatement stm = conexion.prepareStatement(sql);
			
			// 2.- Resolver el parametro "Empieza a contar desde 1"
			stm.setInt(1, id);
			
			
			// 3.- Lanzar la query y recoger el resultado
			ResultSet rs = stm.executeQuery();
			
			// 4.- Procesar el resultado
			if(rs.next()) {
				encontrado =  new Producto(rs.getInt("ID"), 
						rs.getString("DESCRIPCION"), 
						rs.getDouble("PRECIO"));
			}
			
		} catch (Exception e) {
			System.out.println("Error al buscar el producto " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return encontrado;
	}

	
	public List<Producto> consultarTodos(){
		
		List<Producto> lista = new ArrayList<Producto>();
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "select * from PRODUCTOS";
			Statement stm = conexion.createStatement();
			
			// 2.- Lanzar la query y recoger el resultado
			ResultSet rs = stm.executeQuery(sql);
			
			// 3.- Procesar el resultado
			while(rs.next()) {
				lista.add(new Producto(rs.getInt("ID"), 
						rs.getString("DESCRIPCION"),
						rs.getDouble("PRECIO")));
			}
			
		} catch (Exception e) {
			System.out.println("Error al consultar todos los productos");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return lista;
	}
	
	
	private void abrirConexion() {

		try {
			// Cargar el driver base de datos
			Class.forName("com.mysql.jdbc.Driver");
			
			// Abrir la conexion
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/Softtek", "root", "");
		} catch (ClassNotFoundException e) {
			System.out.println("Error, no encuentra el driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("No se pudo abrir la conexion");
			e.printStackTrace();
		}
	}
	
	private void cerrarConexion() {
		try {
			conexion.close();
		} catch (SQLException e) {
			System.out.println("No se pudo cerrar la conexion");
			e.printStackTrace();
		}
	}

}
