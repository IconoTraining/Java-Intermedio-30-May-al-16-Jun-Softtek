package com.softtek.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.softtek.business.NegocioTienda;
import com.softtek.models.Producto;


@WebServlet("/tienda")
public class ServletTienda extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	NegocioTienda negocio = new NegocioTienda();
       
	private String consultarTodos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Producto> lista = negocio.todos();
		
		// Para poder enviar la lista de productos a la pagina JSP
		// la guardo como atributo de peticion
		request.setAttribute("todos", lista);
		
		return "/mostrarTodos.jsp";
	}
	
	private String buscarProducto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Producto encontrado = negocio.buscar(Integer.parseInt(request.getParameter("codigo")));
		
		if (encontrado.getId() == 0) {
			// No ha encontrado el producto
			request.setAttribute("mensaje", "Producto no encontrado");
			return "/mostrarMensaje.jsp";
		} else {
			// Hemos encontrado el producto
			request.setAttribute("encontrado", encontrado);
			return "/mostrarProducto.jsp";
		}
	}
		
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String vista = "/index.jsp";
		
		// Necesito saber que me esta pidiendo el usuario
		switch (request.getParameter("op")) {
		
			case "1":    // consultar todos los productos
				vista = consultarTodos(request, response);
				break;
	
			case "2":    // buscar un producto
				vista = buscarProducto(request, response);
				break;
	
			} 
		
		
		// Elegir la vista que mostrara la respuesta
		RequestDispatcher rd = request.getRequestDispatcher(vista);
		
		// Redirigir hacia esa vista
		rd.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
