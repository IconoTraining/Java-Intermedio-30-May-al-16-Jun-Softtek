package com.softtek.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.softtek.business.NegocioTienda;
import com.softtek.models.Producto;


@WebServlet("/tienda")
public class ServletTienda extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		NegocioTienda negocio = new NegocioTienda();
		List<Producto> lista = negocio.todos();
		
		// Para poder enviar la lista de productos a la pagina JSP
		// la guardo como atributo de peticion
		request.setAttribute("todos", lista);
		
		// Elegir la vista que mostrara la respuesta
		RequestDispatcher rd = request.getRequestDispatcher("/mostrarTodos.jsp");
		
		// Redirigir hacia esa vista
		rd.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
