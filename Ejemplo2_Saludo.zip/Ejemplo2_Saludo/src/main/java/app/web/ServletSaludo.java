package app.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletSaludo
 */
@WebServlet("/saludo")
public class ServletSaludo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Recuperar el parametro nombreUsuario
		String datoRecibido = request.getParameter("nombreUsuario");
		
		/*
		 * mostrar el mensaje en la misma pagina
			response.getWriter().write("Bienvenido " + datoRecibido + " a mi pagina web");
		*/
		
		// Guardar el dato recibido como atributo de la peticion
		request.setAttribute("nombre", datoRecibido);
		
		// Redirigir a otra pagina (mostrarMensaje.jsp)
		RequestDispatcher rd = request.getRequestDispatcher("/mostrarMensaje.jsp");
		rd.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
