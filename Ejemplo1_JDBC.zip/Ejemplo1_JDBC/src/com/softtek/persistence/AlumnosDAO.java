package com.softtek.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;


import com.softtek.models.Alumno;

// DAO -> Data Access Object
public class AlumnosDAO {
	
	private Connection conexion;
	
	public void modificarAlumno(int id, double nuevaNota){
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "update Alumnos set NOTA=? where ID=?";
			PreparedStatement stm = conexion.prepareStatement(sql);
			
			// 2.- Resolver los parametros "Empieza a contar desde 1"
			stm.setDouble(1, nuevaNota);
			stm.setInt(2, id);		
			
			// 3.- Lanzar la query y recoger el resultado
			int registros = stm.executeUpdate();
			
			// 4.- Procesar el resultado
			if(registros == 1) {
				System.out.println("Alumno " + id + " modificado");
			}
			
		} catch (Exception e) {
			System.out.println("Error al modificar el alumno con id " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
	}
	
	public void borrarAlumno(int id){
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "delete from Alumnos where ID=?";
			PreparedStatement stm = conexion.prepareStatement(sql);
			
			// 2.- Resolver los parametros "Empieza a contar desde 1"
			stm.setInt(1, id);		
			
			// 3.- Lanzar la query y recoger el resultado
			int registros = stm.executeUpdate();
			
			// 4.- Procesar el resultado
			if(registros == 1) {
				System.out.println("Alumno " + id + " eliminado");
			}
			
		} catch (Exception e) {
			System.out.println("Error al eliminar el alumno con id " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
	}
	
	public void insertarAlumno(Alumno nuevo){
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "insert into Alumnos values (?,?,?,?)";
			PreparedStatement stm = conexion.prepareStatement(sql);
			
			// 2.- Resolver los parametros "Empieza a contar desde 1"
			stm.setInt(1, nuevo.getId());
			stm.setString(2, nuevo.getNombre());
			stm.setString(3, nuevo.getApellido());
			stm.setDouble(4, nuevo.getNota());
			
			// 3.- Lanzar la query y recoger el resultado
			int registros = stm.executeUpdate();
			
			// 4.- Procesar el resultado
			if(registros == 1) {
				System.out.println("Alumno " + nuevo.getNombre() + " insertado");
			}
			
		} catch (Exception e) {
			System.out.println("Error al insertar el alumno " + nuevo);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
	}
	
	public Alumno buscarAlumno(String nombre){
		
		Alumno encontrado = new Alumno();
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "select * from Alumnos where NOMBRE = ?";
			PreparedStatement stm = conexion.prepareStatement(sql);
			
			// 2.- Resolver el parametro "Empieza a contar desde 1"
			stm.setString(1, nombre);
			
			
			// 3.- Lanzar la query y recoger el resultado
			ResultSet rs = stm.executeQuery();
			
			// 4.- Procesar el resultado
			if(rs.next()) {
				encontrado =  new Alumno(rs.getInt("ID"), rs.getString("NOMBRE"), 
						rs.getString("APELLIDO"), rs.getDouble("NOTA"));
			}
			
		} catch (Exception e) {
			System.out.println("Error al buscar el alumno " + nombre);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return encontrado;
	}

	
	public List<Alumno> consultarTodos(){
		
		List<Alumno> lista = new ArrayList<Alumno>();
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "select * from Alumnos";
			Statement stm = conexion.createStatement();
			
			// 2.- Lanzar la query y recoger el resultado
			ResultSet rs = stm.executeQuery(sql);
			
			// 3.- Procesar el resultado
			while(rs.next()) {
				lista.add(new Alumno(rs.getInt("ID"), rs.getString("NOMBRE"), 
						rs.getString("APELLIDO"), rs.getDouble("NOTA")));
			}
			
		} catch (Exception e) {
			System.out.println("Error al consultar todos los alumnos");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return lista;
	}
	
	
	private void abrirConexion() {

		try {
			// Cargar el driver base de datos
			Class.forName("com.mysql.jdbc.Driver");
			
			// Abrir la conexion
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/Softtek", "root", "");
		} catch (ClassNotFoundException e) {
			System.out.println("Error, no encuentra el driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("No se pudo abrir la conexion");
			e.printStackTrace();
		}
	}
	
	private void cerrarConexion() {
		try {
			conexion.close();
		} catch (SQLException e) {
			System.out.println("No se pudo cerrar la conexion");
			e.printStackTrace();
		}
	}

}
