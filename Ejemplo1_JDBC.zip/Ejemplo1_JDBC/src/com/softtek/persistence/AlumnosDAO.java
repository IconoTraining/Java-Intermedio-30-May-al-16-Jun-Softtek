package com.softtek.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.softtek.models.Alumno;

// DAO -> Data Access Object
public class AlumnosDAO {
	
	private Connection conexion;
	
	public List<Alumno> consultarTodos(){
		
		List<Alumno> lista = new ArrayList<Alumno>();
		
		try {
			// 0.- Abrir la conexion
			abrirConexion();
			
			// 1.- Crear una query
			String sql = "select * from Alumnos";
			Statement stm = conexion.createStatement();
			
			// 2.- Lanzar la query y recoger el resultado
			ResultSet rs = stm.executeQuery(sql);
			
			// 3.- Procesar el resultado
			while(rs.next()) {
				lista.add(new Alumno(rs.getInt("ID"), rs.getString("NOMBRE"), 
						rs.getString("APELLIDO"), rs.getDouble("NOTA")));
			}
			
		} catch (Exception e) {
			System.out.println("Error al consultar todos los alumnos");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return lista;
	}
	
	
	private void abrirConexion() {

		try {
			// Cargar el driver base de datos
			Class.forName("com.mysql.jdbc.Driver");
			
			// Abrir la conexion
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/Softtek", "root", "");
		} catch (ClassNotFoundException e) {
			System.out.println("Error, no encuentra el driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("No se pudo abrir la conexion");
			e.printStackTrace();
		}
	}
	
	private void cerrarConexion() {
		try {
			conexion.close();
		} catch (SQLException e) {
			System.out.println("No se pudo cerrar la conexion");
			e.printStackTrace();
		}
	}

}
