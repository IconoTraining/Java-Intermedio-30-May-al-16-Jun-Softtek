package com.softtek.main;


import com.softtek.models.Alumno;
import com.softtek.persistence.AlumnosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		AlumnosDAO dao = new AlumnosDAO();
		
		for(Alumno alum : dao.consultarTodos()) {
			System.out.println(alum);
		}

	}

}
