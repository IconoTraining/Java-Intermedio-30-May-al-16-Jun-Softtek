package com.softtek.main;


import com.softtek.models.Alumno;
import com.softtek.persistence.AlumnosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		AlumnosDAO dao = new AlumnosDAO();
		
		for(Alumno alum : dao.consultarTodos()) {
			System.out.println(alum);
		}
		
		System.out.println("Alumnos encontrado: " + dao.buscarAlumno("Maria"));
		
		dao.borrarAlumno(4);
		
		dao.insertarAlumno(new Alumno(4,"Pepito","Perez",2.5));
		
		dao.modificarAlumno(4, 5.2);

	}

}
