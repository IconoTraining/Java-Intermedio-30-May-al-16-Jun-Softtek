package com.softtek.web;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

// Intercepto todas las peticiones
@WebFilter("/*")
public class FiltroTiempo implements Filter {

 

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		// interceptamos la peticion
		long tiempoInicio = System.currentTimeMillis();
		System.out.println("Se ha tomado el tiempo de inicio");
		
		chain.doFilter(request, response);
		
		// interceptamos la respuesta
		long tiempoFinal = System.currentTimeMillis();
		System.out.println("Se ha tomado el tiempo final");
		long diferencia = tiempoFinal - tiempoInicio;
		System.out.println("El tiempo de respuesta es " + diferencia + " mseg.");
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
