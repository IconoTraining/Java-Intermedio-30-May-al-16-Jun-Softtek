package com.softtek.ws;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONObject;

import com.softtek.business.NegocioTienda;
import com.softtek.models.Producto;

@Path("/")
public class ProductosREST {
	
	// API Rest
	// Get -> Consultas
	// Delete -> Eliminar
	// Post -> Alta
	// Put -> Modificar
	
	private NegocioTienda negocio = new NegocioTienda();
	
	// http://localhost:8080/Ejemplo10_TiendaProductos_ServiciosREST/servlet/consultar
	@GET
	@Path("consultar")
	@Produces("application/json")
	public String consultarTodos() {
		List<Producto> lista = negocio.todos();
		JSONArray array = new JSONArray(lista);
		return array.toString();
	}
	
	// http://localhost:8080/Ejemplo10_TiendaProductos_ServiciosREST/servlet/consultar/3
	@GET
	@Path("consultar/{codigo}")
	@Produces("application/json")
	public String buscar(@PathParam("codigo") int id) {
		Producto producto = negocio.buscar(id);
		JSONObject json = new JSONObject(producto);
		return json.toString();
	}
	
	// http://localhost:8080/Ejemplo10_TiendaProductos_ServiciosREST/servlet/eliminar/3
	@DELETE
	@Path("eliminar/{codigo}")
	@Produces("application/json")
	public String borrar(@PathParam("codigo") int id) {
		boolean eliminado = negocio.borrar(id);
		JSONObject json = new JSONObject();
		json.put("eliminado", eliminado);
		return json.toString();
	}
	
	// http://localhost:8080/Ejemplo10_TiendaProductos_ServiciosREST/servlet/modificar
	@PUT
	@Path("modificar")
	@Produces("application/json")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public String modificar(@FormParam("id") int id,
			@FormParam("precio") double precio) {
		boolean modificado = negocio.modificar(id, precio);
		JSONObject json = new JSONObject();
		json.put("modificado", modificado);
		return json.toString();
	}
	
	// http://localhost:8080/Ejemplo10_TiendaProductos_ServiciosREST/servlet/alta
	@POST
	@Path("alta")
	@Produces("application/json")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public String alta(@FormParam("id") int id,
				@FormParam("descripcion") String descripcion,
				@FormParam("precio") double precio) {
			Producto nuevo = new Producto(id, descripcion, precio);
			boolean insertado = negocio.alta(nuevo);
			JSONObject json = new JSONObject();
			json.put("insertado", insertado);
			return json.toString();
		}
	
}










