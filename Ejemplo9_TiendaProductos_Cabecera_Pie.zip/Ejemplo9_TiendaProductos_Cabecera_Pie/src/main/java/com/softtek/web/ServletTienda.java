package com.softtek.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.softtek.business.Carrito;
import com.softtek.business.NegocioTienda;
import com.softtek.models.Producto;


@WebServlet(
		urlPatterns = {"/tienda"}, 
		initParams = {
				@WebInitParam(name = "Oferta", value = "Hoy 10% de dto en todos los productos" )
		} )
public class ServletTienda extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	NegocioTienda negocio = new NegocioTienda();
	
       
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
		System.out.println("La instancia del servlet se va a destruir");
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		// Recuperar los parametros iniciales del Servlet
		String mensaje = config.getInitParameter("Oferta");
		
		// Acceder el ambito de la aplicacion
		ServletContext ctxApp = config.getServletContext();
		
		// En el contexto de la aplicacion guardamos como atributo el mensaje
		ctxApp.setAttribute("msgOferta", mensaje);
		
		System.out.println("El servlet ya se ha instanciado");
	}

	private String consultarTodos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Producto> lista = negocio.todos();
		
		// Para poder enviar la lista de productos a la pagina JSP
		// la guardo como atributo de peticion
		request.setAttribute("todos", lista);
		
		return "/mostrarTodos.jsp";
	}
	
	private String buscarProducto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Producto encontrado = negocio.buscar(Integer.parseInt(request.getParameter("codigo")));
		
		if (encontrado.getId() == 0) {
			// No ha encontrado el producto
			request.setAttribute("mensaje", "Producto no encontrado");
			return "/mostrarMensaje.jsp";
		} else {
			// Hemos encontrado el producto
			request.setAttribute("encontrado", encontrado);
			return "/mostrarProducto.jsp";
		}
	}
	
	private String altaProducto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Producto nuevo = new Producto(Integer.parseInt(request.getParameter("codigo")), 
				request.getParameter("desc"), Double.parseDouble(request.getParameter("pre")));
		
		if (negocio.alta(nuevo)) {
			request.setAttribute("mensaje", "Producto insertado correctamente");
		} else {
			request.setAttribute("mensaje", "No se pudo insertar el producto");
		}
		
		return "/mostrarMensaje.jsp";
	}
	
	private String borrarProducto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if (negocio.borrar(Integer.parseInt(request.getParameter("codigo")))) {
			request.setAttribute("mensaje", "Producto eliminado correctamente");
		} else {
			request.setAttribute("mensaje", "No se pudo eliminar el producto");
		}
		
		return "/mostrarMensaje.jsp";
	}
		
	private String modificarProducto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if (negocio.modificar(Integer.parseInt(request.getParameter("codigo")), 
				Double.parseDouble(request.getParameter("pre")))) {
			request.setAttribute("mensaje", "Producto modificado correctamente");
		} else {
			request.setAttribute("mensaje", "No se pudo modificar el producto");
		}
		
		return "/mostrarMensaje.jsp";
	}
    
	private String comprarProducto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Recuperar todas las cookies
		Cookie[] cookies = request.getCookies();
		
		// buscar si existe la cookie "nombreUsuario"
		boolean logado = false;
		String nombre = "";
		for (Cookie cookie : cookies) {
			if (cookie.getName().equals("nombreUsuario")) {

				// Si existe, guardo el nombre
				nombre = cookie.getValue();
				logado = true;
			}
		}
		
		if (logado) {
			// Si esta logado, continuamos con el proceso de compra
			// Crear o recuperar la session del usuario
			HttpSession session = request.getSession(true); // si no existe, la crea
			
			// Guardo el nombre del usuario como atributo de session
			session.setAttribute("nombreUsuario", nombre);
			
			Carrito carro = (Carrito) session.getAttribute("miCarro");
			
			if (carro == null) {
				carro = new Carrito();
				session.setAttribute("miCarro", carro);
			}
			
			carro.addProducto(Integer.parseInt(request.getParameter("codigo")));
			
			return "/mostrarCarrito.jsp";
		} else {
			// Si no esta logado, enviamos al usuario al formularioLogin.html
			return "/formularioLogin.html";
		}
		
	}
	
	private String sacarProducto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Recuperar la session del usuario
		HttpSession session = request.getSession(false);  // Si no existe NO la crea
		
		Carrito carro = (Carrito) session.getAttribute("miCarro");
		carro.sacarProducto(Integer.parseInt(request.getParameter("codigo")));
		
		return "/mostrarCarrito.jsp";
	}	
	
	private String crearCookie(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		// Recuperar el nombre del usuario
		String dato = request.getParameter("nombre");
		
		// Comprobar si existe....
		
		// crear una cookie con el name = "nombreUsuario"
		Cookie miCookie = new Cookie("nombreUsuario", dato);
		
		// Tiempo maximo 3 horas
		miCookie.setMaxAge(3*60*60);
		
		// Adjuntar la cookie a la respuesta
		response.addCookie(miCookie);
		
		return "/index.jsp";
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Desde el objeto request tambien puedo acceder al ambito de aplicacion
		//ServletContext ctxApp = request.getServletContext();
		
		String vista = "/index.jsp";
		
		// Necesito saber que me esta pidiendo el usuario
		switch (request.getParameter("op")) {
		
			case "1":    // consultar todos los productos
				vista = consultarTodos(request, response);
				break;
	
			case "2":    // buscar un producto
				vista = buscarProducto(request, response);
				break;
				
			case "3":    // alta de producto
				vista = altaProducto(request, response);
				break;
				
			case "4":    // borrar un producto
				vista = borrarProducto(request, response);
				break;
				
			case "5":    // modificar un producto
				vista = modificarProducto(request, response);
				break;
				
			case "6":    // comprar un producto
				vista = comprarProducto(request, response);
				break;
			
			case "7":    // sacar un producto del carrito
				vista = sacarProducto(request, response);
				break;
			
			case "8":    // crear cookie con nombre
				vista = crearCookie(request, response);
				break;
			
			} 
		
		
		// Elegir la vista que mostrara la respuesta
		RequestDispatcher rd = request.getRequestDispatcher(vista);
		
		// Redirigir hacia esa vista
		rd.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
