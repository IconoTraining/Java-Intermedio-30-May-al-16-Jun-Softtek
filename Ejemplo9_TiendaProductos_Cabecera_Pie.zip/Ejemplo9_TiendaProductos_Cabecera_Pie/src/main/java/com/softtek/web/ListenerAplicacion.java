package com.softtek.web;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class ListenerAplicacion
 *
 */
@WebListener
public class ListenerAplicacion implements ServletContextListener {

    public void contextDestroyed(ServletContextEvent sce)  { 
         System.out.println("Se va destruir la aplicacion");
    }

    public void contextInitialized(ServletContextEvent sce)  { 
    	// Accedemos al contexto de la aplicacion
    	 ServletContext ctxApp =  sce.getServletContext();
    	 
    	 // Recuperamos el parametro inicial de la aplicacion
    	 String mensaje = ctxApp.getInitParameter("diaSinIva");
    	 
    	 // Lo guardo como atributo de aplicacion
    	 ctxApp.setAttribute("iva", mensaje);
    	 
         System.out.println("Se acaba de hacer el deploy");
    }
	
}
