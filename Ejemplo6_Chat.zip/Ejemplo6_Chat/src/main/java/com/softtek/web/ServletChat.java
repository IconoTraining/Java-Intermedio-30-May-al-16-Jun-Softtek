package com.softtek.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletChat
 */
@WebServlet("/chat")
public class ServletChat extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	public void init() throws ServletException {
		super.init();
			
		// Crear la lista de mensajes y guardarla en el contexto de la aplicacion
		List<String> lista = new ArrayList<String>();
		getServletContext().setAttribute("mensajes", lista);			
	}
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession miSession = request.getSession();
		
		if (request.getParameter("op").equals("2")) {  // login	
			miSession.setAttribute("nombreUsuario", request.getParameter("nombre"));
			
			// dirigir al index.jsp
			RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
		
		if (request.getParameter("op").equals("1")) { // poner el mensaje
			String nombre = (String) miSession.getAttribute("nombreUsuario");
			
			if (nombre == null) {
				RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
				rd.forward(request, response);
			} else {
				// recuperar el mensaje
				String mensaje = request.getParameter("msg");
				
				// Deberiamos tener una lista de mensajes guardada en el contexto de la aplicacion
				List<String> lista = (List<String>) request.getServletContext().getAttribute("mensajes");
				
				// acceder a esa lista, añadir el mensaje recibido
				lista.add(nombre + ":" + mensaje);
				
				// dirigir al index.jsp
				RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
				rd.forward(request, response);
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
