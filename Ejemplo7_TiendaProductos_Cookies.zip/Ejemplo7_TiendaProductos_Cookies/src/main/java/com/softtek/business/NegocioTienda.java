package com.softtek.business;

import java.util.List;

import com.softtek.models.Producto;
import com.softtek.persistence.ProductosDAO;

public class NegocioTienda {
	
	private ProductosDAO dao = new ProductosDAO();
	
	public List<Producto> todos(){
		return dao.consultarTodos();
	}
	
	public Producto buscar(int id) {
		return dao.buscarProducto(id);
	}
	
	public boolean alta(Producto producto) {
		return dao.insertarProducto(producto);
	}
	
	public boolean borrar(int id) {
		return dao.borrarProducto(id);
	}
	
	public boolean modificar(int id, double precio) {
		return dao.modificarProducto(id, precio);
	}

}
